import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar, Users, CheckCircle, XCircle, RefreshCw, MessageCircle, Scissors } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from "recharts";
import { toast } from "sonner";
import { Link } from "react-router-dom";

interface Stats {
  total: number;
  confirmed: number;
  cancelled: number;
  rescheduled: number;
  pending: number;
  completed: number;
}

const Dashboard = () => {
  const [stats, setStats] = useState<Stats>({
    total: 0,
    confirmed: 0,
    cancelled: 0,
    rescheduled: 0,
    pending: 0,
    completed: 0,
  });
  const [recentAppointments, setRecentAppointments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    try {
      const { data: appointments, error } = await supabase
        .from("appointments")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) throw error;

      const statsData: Stats = {
        total: appointments?.length || 0,
        confirmed: appointments?.filter((a) => a.status === "confirmed").length || 0,
        cancelled: appointments?.filter((a) => a.status === "cancelled").length || 0,
        rescheduled: appointments?.filter((a) => a.status === "rescheduled").length || 0,
        pending: appointments?.filter((a) => a.status === "pending").length || 0,
        completed: appointments?.filter((a) => a.status === "completed").length || 0,
      };

      setStats(statsData);
      setRecentAppointments(appointments?.slice(0, 5) || []);
    } catch (error) {
      console.error("Error fetching data:", error);
      toast.error("Erro ao carregar dados");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();

    const channel = supabase
      .channel("appointments-changes")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "appointments",
        },
        () => {
          fetchData();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const handleWhatsAppClick = () => {
    const message = encodeURIComponent(
      "Olá! Gostaria de agendar um horário na Barber Shop."
    );
    window.open(`https://wa.me/558586594281?text=${message}`, "_blank");
  };

  const chartData = [
    { name: "Confirmados", value: stats.confirmed, color: "hsl(var(--success))" },
    { name: "Cancelados", value: stats.cancelled, color: "hsl(var(--destructive))" },
    { name: "Reagendados", value: stats.rescheduled, color: "hsl(var(--warning))" },
    { name: "Pendentes", value: stats.pending, color: "hsl(var(--muted))" },
    { name: "Concluídos", value: stats.completed, color: "hsl(var(--primary))" },
  ];

  const statusColors: Record<string, string> = {
    confirmed: "success",
    cancelled: "destructive",
    rescheduled: "warning",
    pending: "muted",
    completed: "primary",
  };

  const statusLabels: Record<string, string> = {
    confirmed: "Confirmado",
    cancelled: "Cancelado",
    rescheduled: "Reagendado",
    pending: "Pendente",
    completed: "Concluído",
  };

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="animate-pulse text-primary">
          <Scissors className="h-12 w-12" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Scissors className="h-8 w-8 text-primary" />
              <h1 className="text-3xl font-bold text-foreground">Barber Shop</h1>
            </div>
            <nav className="flex gap-4">
              <Link to="/">
                <Button variant="ghost">Dashboard</Button>
              </Link>
              <Link to="/customers">
                <Button variant="ghost">Clientes</Button>
              </Link>
              <Link to="/appointments">
                <Button variant="ghost">Agendamentos</Button>
              </Link>
            </nav>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="mb-8 flex items-center justify-between">
          <h2 className="text-2xl font-bold text-foreground">Dashboard</h2>
          <Button onClick={handleWhatsAppClick} className="gap-2">
            <MessageCircle className="h-4 w-4" />
            Agendar via WhatsApp
          </Button>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 mb-8">
          <Card className="border-border bg-card hover:shadow-lg hover:shadow-primary/5 transition-all">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-foreground">
                <Calendar className="h-5 w-5 text-primary" />
                Total de Agendamentos
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-4xl font-bold text-primary">{stats.total}</p>
            </CardContent>
          </Card>

          <Card className="border-border bg-card hover:shadow-lg hover:shadow-success/5 transition-all">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-foreground">
                <CheckCircle className="h-5 w-5 text-success" />
                Confirmados
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-4xl font-bold text-success">{stats.confirmed}</p>
            </CardContent>
          </Card>

          <Card className="border-border bg-card hover:shadow-lg hover:shadow-destructive/5 transition-all">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-foreground">
                <XCircle className="h-5 w-5 text-destructive" />
                Cancelados
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-4xl font-bold text-destructive">{stats.cancelled}</p>
            </CardContent>
          </Card>

          <Card className="border-border bg-card hover:shadow-lg hover:shadow-warning/5 transition-all">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-foreground">
                <RefreshCw className="h-5 w-5 text-warning" />
                Reagendados
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-4xl font-bold text-warning">{stats.rescheduled}</p>
            </CardContent>
          </Card>

          <Card className="border-border bg-card hover:shadow-lg hover:shadow-muted/5 transition-all">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-foreground">
                <Calendar className="h-5 w-5 text-muted-foreground" />
                Pendentes
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-4xl font-bold text-muted-foreground">{stats.pending}</p>
            </CardContent>
          </Card>

          <Card className="border-border bg-card hover:shadow-lg hover:shadow-primary/5 transition-all">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-foreground">
                <CheckCircle className="h-5 w-5 text-primary" />
                Concluídos
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-4xl font-bold text-primary">{stats.completed}</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-6 lg:grid-cols-2 mb-8">
          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle className="text-foreground">Distribuição de Status</CardTitle>
              <CardDescription className="text-muted-foreground">
                Visualização geral dos agendamentos
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={chartData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, value }) => `${name}: ${value}`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {chartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "var(--radius)",
                    }}
                  />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle className="text-foreground">Status dos Agendamentos</CardTitle>
              <CardDescription className="text-muted-foreground">
                Comparativo por categoria
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" />
                  <YAxis stroke="hsl(var(--muted-foreground))" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "var(--radius)",
                    }}
                  />
                  <Bar dataKey="value" fill="hsl(var(--primary))" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        <Card className="border-border bg-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-foreground">
              <Calendar className="h-5 w-5 text-primary" />
              Agendamentos Recentes
            </CardTitle>
            <CardDescription className="text-muted-foreground">
              Últimos 5 agendamentos registrados
            </CardDescription>
          </CardHeader>
          <CardContent>
            {recentAppointments.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">
                Nenhum agendamento encontrado
              </p>
            ) : (
              <div className="space-y-4">
                {recentAppointments.map((appointment) => (
                  <div
                    key={appointment.id}
                    className="flex items-center justify-between p-4 rounded-lg border border-border bg-secondary hover:bg-secondary/80 transition-colors"
                  >
                    <div className="flex-1">
                      <p className="font-semibold text-foreground">
                        {appointment.customer_name}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {appointment.customer_phone}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {appointment.service}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium text-foreground">
                        {new Date(appointment.appointment_date).toLocaleDateString("pt-BR")}
                      </p>
                      <span
                        className={`inline-block px-3 py-1 rounded-full text-xs font-semibold mt-2 bg-${statusColors[appointment.status]} text-${statusColors[appointment.status]}-foreground`}
                      >
                        {statusLabels[appointment.status]}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
};

export default Dashboard;
