import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Calendar, Plus, Scissors, Phone, Clock } from "lucide-react";
import { toast } from "sonner";
import { Link } from "react-router-dom";

interface Appointment {
  id: string;
  customer_name: string;
  customer_phone: string;
  service: string;
  appointment_date: string;
  status: string;
  created_at: string;
}

const Appointments = () => {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    service: "",
    appointment_date: "",
  });

  const fetchAppointments = async () => {
    try {
      const { data, error } = await supabase
        .from("appointments")
        .select("*")
        .order("appointment_date", { ascending: false });

      if (error) throw error;
      setAppointments(data || []);
    } catch (error) {
      console.error("Error fetching appointments:", error);
      toast.error("Erro ao carregar agendamentos");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAppointments();

    const channel = supabase
      .channel("appointments-changes")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "appointments",
        },
        () => {
          fetchAppointments();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name || !formData.phone || !formData.service || !formData.appointment_date) {
      toast.error("Todos os campos são obrigatórios");
      return;
    }

    try {
      const { error } = await supabase.from("appointments").insert([
        {
          customer_name: formData.name,
          customer_phone: formData.phone,
          service: formData.service,
          appointment_date: formData.appointment_date,
        },
      ]);

      if (error) throw error;

      // Send data to webhook
      const webhookPayload = {
        nome: formData.name,
        telefone: formData.phone,
        servico: formData.service,
        data: formData.appointment_date,
      };

      const webhookResponse = await fetch("https://robot.keycore.com.br/webhook/Evolution", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(webhookPayload),
      });

      if (!webhookResponse.ok) {
        throw new Error("Falha ao enviar agendamento para o webhook");
      }

      toast.success("Agendamento criado com sucesso!");
      setFormData({ name: "", phone: "", service: "", appointment_date: "" });
      setOpen(false);
    } catch (error: any) {
      console.error("Error creating appointment or sending to webhook:", error);
      toast.error("Erro ao criar agendamento ou enviar para o webhook");
    }
  };

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="animate-pulse text-primary">
          <Scissors className="h-12 w-12" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Scissors className="h-8 w-8 text-primary" />
              <h1 className="text-3xl font-bold text-foreground">Barber Shop</h1>
            </div>
            <nav className="flex gap-4">
              <Link to="/">
                <Button variant="ghost">Dashboard</Button>
              </Link>
              <Link to="/customers">
                <Button variant="ghost">Clientes</Button>
              </Link>
              <Link to="/appointments">
                <Button variant="ghost">Agendamentos</Button>
              </Link>
            </nav>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="mb-8 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Calendar className="h-8 w-8 text-primary" />
            <h2 className="text-2xl font-bold text-foreground">Agendamentos</h2>
          </div>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                Novo Agendamento
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-card border-border">
              <DialogHeader>
                <DialogTitle className="text-foreground">Cadastrar Novo Agendamento</DialogTitle>
                <DialogDescription className="text-muted-foreground">
                  Preencha os dados do agendamento
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-foreground">
                    Nome *
                  </Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Digite o nome completo"
                    required
                    className="bg-background border-border text-foreground"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone" className="text-foreground">
                    Telefone *
                  </Label>
                  <Input
                    id="phone"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="(00) 00000-0000"
                    required
                    className="bg-background border-border text-foreground"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="service" className="text-foreground">
                    Serviço *
                  </Label>
                  <Input
                    id="service"
                    value={formData.service}
                    onChange={(e) => setFormData({ ...formData, service: e.target.value })}
                    placeholder="Ex: Corte de cabelo"
                    required
                    className="bg-background border-border text-foreground"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="appointment_date" className="text-foreground">
                    Data e Hora *
                  </Label>
                  <Input
                    id="appointment_date"
                    type="datetime-local"
                    value={formData.appointment_date}
                    onChange={(e) => setFormData({ ...formData, appointment_date: e.target.value })}
                    required
                    className="bg-background border-border text-foreground"
                  />
                </div>
                <Button type="submit" className="w-full">
                  Criar Agendamento
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {appointments.length === 0 ? (
            <Card className="col-span-full border-border bg-card">
              <CardContent className="py-12">
                <p className="text-center text-muted-foreground">
                  Nenhum agendamento cadastrado ainda
                </p>
              </CardContent>
            </Card>
          ) : (
            appointments.map((appointment) => (
              <Card
                key={appointment.id}
                className="border-border bg-card hover:shadow-lg hover:shadow-primary/5 transition-all"
              >
                <CardHeader>
                  <CardTitle className="text-foreground">{appointment.customer_name}</CardTitle>
                  <CardDescription className="text-muted-foreground">
                    {appointment.service}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex items-center gap-2 text-foreground">
                    <Phone className="h-4 w-4 text-primary" />
                    <span className="text-sm">{appointment.customer_phone}</span>
                  </div>
                  <div className="flex items-center gap-2 text-foreground">
                    <Clock className="h-4 w-4 text-primary" />
                    <span className="text-sm">
                      {new Date(appointment.appointment_date).toLocaleString("pt-BR")}
                    </span>
                  </div>
                  <Badge variant={appointment.status === 'confirmed' ? 'default' : 'secondary'}>
                    {appointment.status}
                  </Badge>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </main>
    </div>
  );
};

export default Appointments;
