import { motion } from "framer-motion";

const ScissorsTransition = () => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-background"
    >
      <motion.div
        initial={{ x: "-100vw" }}
        animate={{ x: "100vw" }}
        transition={{ duration: 1, ease: "easeInOut" }}
        className="flex items-center"
      >
        <motion.svg
          width="100"
          height="100"
          viewBox="0 0 100 100"
          animate={{
            rotate: [0, 10, -10, 0],
          }}
          transition={{
            duration: 0.5,
            repeat: Infinity,
            repeatType: "reverse",
          }}
        >
          {/* Scissors */}
          <path
            d="M20 30 L50 50 L20 70 L30 80 L60 60 L90 80 L80 70 L50 50 L80 30 L90 20 L60 40 L30 20 Z"
            fill="hsl(var(--primary))"
          />
          <circle cx="25" cy="25" r="5" fill="hsl(var(--background))" />
          <circle cx="75" cy="75" r="5" fill="hsl(var(--background))" />
        </motion.svg>
      </motion.div>
    </motion.div>
  );
};

export default ScissorsTransition;
